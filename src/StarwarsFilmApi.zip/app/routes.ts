import { Routes } from '@angular/router';
import { SwapiComponent } from './swapi/swapi.component';

export const allAppRoutes: Routes =[
    {path: '', component: SwapiComponent}
];